import tkinter as tk
import random

# Global variables for player and computer markers
player = ""
computer = ""

def start_game(player_choice):
    global player, computer
    player = player_choice
    computer = "O" if player == "X" else "X"
    choice_window.destroy()
    init_game_window()

def init_game_window():
    global window, you_label, computer_label, status_label, buttons, player_turn, board

    window = tk.Tk()
    window.title("Tic-Tac-Toe Almadrasa")
    window.geometry("400x500")
    window.maxsize(height=500, width=400)
    window.minsize(height=500, width=400)

    window.grid_rowconfigure(0, weight=1)  # Score section
    window.grid_rowconfigure(1, weight=1)  # Winning status section
    window.grid_rowconfigure(2, weight=1)  # Restart button section
    window.grid_rowconfigure(3, weight=6)  # Game board section

    window.grid_columnconfigure(0, weight=1)
    window.grid_columnconfigure(1, weight=1)
    window.grid_columnconfigure(2, weight=1)

    
    
    # Score
    frame = tk.Frame(window)
    frame.grid(row=0, column=0, columnspan=3)

    you_label = tk.Label(frame, text="You: 0", font=("Arial", 16))
    you_label.grid(column=0, row=0, padx=20, pady=20)
    you_label.config(anchor="center")

    computer_label = tk.Label(frame, text="Computer: 0", font=("Arial", 16))
    computer_label.grid(column=1, row=0, padx=20, pady=20)
    computer_label.config(anchor="center")

    
    
    # Winning status
    status_label = tk.Label(window, text="", font=("Arial", 24))
    status_label.grid(row=1, column=0, columnspan=3)

    
    
    # Restart button
    restart_frame = tk.Frame(window)
    restart_frame.grid(row=2, column=0, columnspan=3)

    restart = tk.Button(restart_frame, text="restart", font=("Arial", 20), width=10, command=lambda: reset_game())
    restart.grid(column=0, row=0, padx=5, pady=5)
    
    
    
    # Game board
    boxes_frame = tk.Frame(window)
    boxes_frame.grid(row=3, column=0, columnspan=3, sticky='nsew')

    for i in range(3):
        boxes_frame.grid_rowconfigure(i, weight=1)
        boxes_frame.grid_columnconfigure(i, weight=1)

   
    # Game state
    player_turn = player
    board = [["" for _ in range(3)] for _ in range(3)]
    buttons = [[None for _ in range(3)] for _ in range(3)]

    
    # Game board buttons
    for i in range(3):
        for j in range(3):
            button = tk.Button(boxes_frame, text=" ", font=("Arial", 30), width=5, height=2,
                               command=lambda row=i, col=j: on_click(row, col))
            button.grid(row=i, column=j, sticky='nsew')
            buttons[i][j] = button
    
    def highlight_cells(cells, color):
        for row, col in cells:
            buttons[row][col].config(bg=color)

    
    
    def check_winner():
        winning_combinations = [
            [(0, 0), (0, 1), (0, 2)],
            [(1, 0), (1, 1), (1, 2)],
            [(2, 0), (2, 1), (2, 2)],
            [(0, 0), (1, 0), (2, 0)],
            [(0, 1), (1, 1), (2, 1)],
            [(0, 2), (1, 2), (2, 2)],
            [(0, 0), (1, 1), (2, 2)],
            [(0, 2), (1, 1), (2, 0)]
        ]
        for combination in winning_combinations:
            cells = [board[row][col] for row, col in combination]
            if cells[0] == cells[1] == cells[2] != "":
                return cells[0], combination
        return None, []

    
    
    def check_tie():
        return all(all(cell != "" for cell in row) for row in board)

    
    
    def on_click(row, col):
        global player_turn
        if board[row][col] == "" and status_label.cget("text") == "":
            board[row][col] = player
            buttons[row][col].config(text=player)
            winner, winning_cells = check_winner()
            if winner:
                status_label.config(text=f"{winner} wins!")
                highlight_cells(winning_cells, "light blue")
                update_score(winner)
            elif check_tie():
                status_label.config(text="It's a tie!")
                highlight_cells([(i, j) for i in range(3) for j in range(3)], "red")
            else:
                player_turn = computer if player_turn == player else player
                if player_turn == computer:
                    computer_move()

    
    
    def computer_move():
        global player_turn
        empty_cells = [(i, j) for i in range(3) for j in range(3) if board[i][j] == ""]
        
        for row, col in empty_cells:
            board[row][col] = computer
            winner, winning_cells = check_winner()
            if winner == computer:
                buttons[row][col].config(text=computer)
                status_label.config(text=f"{computer} wins!")
                highlight_cells(winning_cells, "red")
                update_score(computer)
                return
            board[row][col] = ""
        
        for row, col in empty_cells:
            board[row][col] = player
            winner, winning_cells = check_winner()
            if winner == player:
                board[row][col] = computer
                buttons[row][col].config(text=computer)
                player_turn = player
                return
            board[row][col] = ""
        
        row, col = random.choice(empty_cells)
        board[row][col] = computer
        buttons[row][col].config(text=computer)
        player_turn = player

    
    
    def update_score(winner):
        if winner == player:
            current_score = int(you_label.cget("text").split(": ")[1])
            you_label.config(text=f"You: {current_score + 1}")
        else:
            current_score = int(computer_label.cget("text").split(": ")[1])
            computer_label.config(text=f"Computer: {current_score + 1}")

    
    
    def reset_game():
        global player_turn, board
        player_turn = player
        board = [["" for _ in range(3)] for _ in range(3)]
        status_label.config(text="")
        for i in range(3):
            for j in range(3):
                buttons[i][j].config(text=" ", bg="SystemButtonFace")



    window.mainloop()

# Player choice window
choice_window = tk.Tk()
choice_window.title("Choose your marker")

choice_frame = tk.Frame(choice_window)
choice_frame.pack(padx=20, pady=20)

tk.Label(choice_frame, text="Choose X or O:", font=("Arial", 16)).pack(pady=10)

tk.Button(choice_frame, text="X", font=("Arial", 16), width=10, command=lambda: start_game("X")).pack(side="left", padx=10)
tk.Button(choice_frame, text="O", font=("Arial", 16), width=10, command=lambda: start_game("O")).pack(side="right", padx=10)

choice_window.mainloop()
